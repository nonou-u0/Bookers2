# frozen_string_literal: true

class Users::RegistrationsController < Devise::RegistrationsController
  def create
    super
    if resource.persisted?  # ユーザーが正常に作成された場合
      flash[:notice] = "You have successfully signed up."  # サクセスメッセージ
    end
  end
end
