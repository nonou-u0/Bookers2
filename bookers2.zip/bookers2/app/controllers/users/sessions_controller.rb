# frozen_string_literal: true

class Users::SessionsController < Devise::SessionsController
  def create
    super
    if user_signed_in?
      flash[:notice] = "You have successfully logged in."
    end
  end

  def destroy
    super
    flash[:notice] = "You have successfully logged out." 
  end
end
